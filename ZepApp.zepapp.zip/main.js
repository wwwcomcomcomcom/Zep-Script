/**
 * Copyright (c) 2022 ZEP Co., LTD
 */

App.showCenterLabel("Hello World");
const adminKey = "admin";
function announce(message) {
  App.players.forEach(player => {
    player.sendMessage(message);
  });
}
let isGaming = false;
let gamingPlayer = [];
App.onDestroy.Add(() => {
  announce("술래잡기 게임이 종료되었습니다.");
  Map.clearAllObjects();
});
App.onStart.Add(() => {
  App.players.forEach(player => {
    player.tag = {
      isGaming: false
    };
  });
  if (App.players.length < 3) {
    App.showCenterLabel("플레이어가 부족합니다.");
    // return;
  }
  announce("술래잡기 게임이 시작되었습니다.");
  App.players.forEach(player => {
    player.tileX = 57;
    player.tileY = 57;
    player.moveSpeed = 0;
    setTimeout(() => {
      player.moveSpeed = 80;
    }, 1000);
    player.tag.isGaming = true;
  });
});
App.onJoinPlayer.Add(player => {
  player.tag = {
    isGaming: false
  };
  player.sendMessage(`안녕 ${player.name} 안녕`);
});
App.addOnKeyDown(81, function (player) {
  announce(`${player.tileX},${player.tileY}`);
  if (App.players.length < 2) {
    player.sendMessage("플레이어가 부족합니다.");
    return;
  }
  App.players.forEach(target => {
    if (target.id === player.id) {
      return;
    }
    const distance = getPlayerDistance(player, target);
    announce(`${player.name}와 ${target.name}의 거리는 ${distance}입니다.`);
    if (distance < 5) {
      player.sendMessage(`${target.name}와 가까워졌습니다.`);
    }
    ;
  });
});
App.onSay.Add((player, message) => {
  if (message === "test") {
    player.sendMessage(`${player.role}`);
    player.spawnAt(57, 57, player.dir);
    App.players.forEach(player => {
      player.spawnAt(57, 57, player.dir);
      player.moveSpeed = 0;
      setTimeout(() => {
        player.moveSpeed = 80;
      }, 1000);
      player.tag.isGaming = true;
    });
  }
});
function getPlayerVec2(player) {
  return new Vec2(player.tileX, player.tileY);
}
function getPlayerDistance(player1, player2) {
  return getPlayerVec2(player1).getDistance(getPlayerVec2(player2));
}
function updateGamePlayers() {
  gamingPlayer = App.players.filter(player => player.tag.isGaming);
}
function startGame() {
  isGaming = true;
  App.players.forEach(player => {
    player.tag.isGaming = true;
  });
  updateGamePlayers();
}
class Vec2 {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
  getDistance(vec) {
    const dx = this.x - vec.x;
    const dy = this.y - vec.y;
    return Math.sqrt(dx * dx + dy * dy);
  }
}